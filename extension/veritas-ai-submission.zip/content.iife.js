var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  class VeritasCapture {
    constructor() {
      __publicField(this, "canvas");
      __publicField(this, "ctx");
      this.canvas = document.createElement("canvas");
      this.ctx = this.canvas.getContext("2d");
    }
    async captureFrame(video) {
      const frame = this.captureFrameDirect(video);
      if (frame) return frame;
      return await this.captureFrameFallback(video);
    }
    captureFrameDirect(video) {
      if (!this.ctx || video.videoWidth === 0 || video.videoHeight === 0) return null;
      const width = video.videoWidth;
      const height = video.videoHeight;
      const MAX_DIMENSION = 640;
      let finalWidth = width;
      let finalHeight = height;
      if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
        const ratio = Math.min(MAX_DIMENSION / width, MAX_DIMENSION / height);
        finalWidth = Math.round(width * ratio);
        finalHeight = Math.round(height * ratio);
      }
      this.canvas.width = finalWidth;
      this.canvas.height = finalHeight;
      try {
        this.ctx.drawImage(video, 0, 0, finalWidth, finalHeight);
        const dataUrl = this.canvas.toDataURL("image/jpeg", 0.8);
        return {
          data: dataUrl.split(",")[1],
          timestamp: video.currentTime
        };
      } catch (e) {
        return null;
      }
    }
    async captureFrameFallback(video) {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: "CAPTURE_TAB" }, async (response) => {
          if (!response || !response.success) {
            resolve(null);
            return;
          }
          const rect = video.getBoundingClientRect();
          try {
            const blob = await fetch(response.dataUrl).then((r) => r.blob());
            const imgBitmap = await createImageBitmap(blob);
            const dpr = window.devicePixelRatio || 1;
            this.canvas.width = 640;
            this.canvas.height = 360;
            if (this.ctx) {
              this.ctx.drawImage(
                imgBitmap,
                rect.left * dpr,
                rect.top * dpr,
                rect.width * dpr,
                rect.height * dpr,
                0,
                0,
                this.canvas.width,
                this.canvas.height
              );
              const dataUrl = this.canvas.toDataURL("image/jpeg", 0.8);
              resolve({
                data: dataUrl.split(",")[1],
                timestamp: video.currentTime
              });
            } else {
              resolve(null);
            }
          } catch (e) {
            console.error("Fallback crop failed", e);
            resolve(null);
          }
        });
      });
    }
    async captureSequence(video, count = 30, intervalMs = 100) {
      const frames = [];
      const testFrame = this.captureFrameDirect(video);
      const useFallback = !testFrame;
      if (testFrame) frames.push(testFrame);
      const finalInterval = useFallback ? Math.max(intervalMs, 300) : intervalMs;
      for (let i = 0; i < count; i++) {
        if (useFallback) {
          const frame = await this.captureFrameFallback(video);
          if (frame) frames.push(frame);
        } else {
          if (i > 0) {
            const frame = this.captureFrameDirect(video);
            if (frame) frames.push(frame);
          }
        }
        if (i < count - 1) {
          await new Promise((resolve) => setTimeout(resolve, finalInterval));
        }
      }
      return frames;
    }
  }
  console.log("Veritas-AI: Content script loaded");
  const style = document.createElement("style");
  style.textContent = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

  .veritas-glass {
    background: rgba(15, 23, 42, 0.85);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.5);
    font-family: 'Inter', sans-serif;
    color: white;
  }
  
  .veritas-btn-pulse {
    animation: veritas-pulse 3s infinite;
  }
  
  @keyframes veritas-pulse {
    0% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0.4); }
    70% { box-shadow: 0 0 0 10px rgba(56, 189, 248, 0); }
    100% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0); }
  }

  .veritas-fade-in {
    animation: veritas-fade-in 0.3s ease-out forwards;
  }

  @keyframes veritas-fade-in {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;
  document.head.appendChild(style);
  class VeritasCore {
    // In a real app, load from storage
    constructor() {
      __publicField(this, "veritasCapture");
      __publicField(this, "analyzing", false);
      __publicField(this, "overlay", null);
      __publicField(this, "consentGiven", false);
      this.veritasCapture = new VeritasCapture();
      this.init();
    }
    init() {
      console.log("Veritas-AI: Init called");
      setInterval(() => {
        this.checkForVideo();
      }, 1e3);
      const observer = new MutationObserver(() => {
        this.checkForVideo();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    checkForVideo() {
      const video = document.querySelector("video");
      const player = document.querySelector("#movie_player") || document.querySelector("#ytd-player");
      if (video && player && !document.querySelector("#veritas-btn")) {
        console.log("Veritas-AI: Player found, injecting button...");
        this.injectButton(player, video);
      }
    }
    injectButton(container, video) {
      if (document.querySelector("#veritas-btn")) return;
      const btn = document.createElement("button");
      btn.id = "veritas-btn";
      btn.className = "veritas-glass veritas-btn-pulse";
      btn.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <span style="font-weight: 700; color: #fff; letter-spacing: 0.5px;">VERITAS SEAL</span>
      </div>
    `;
      Object.assign(btn.style, {
        position: "absolute",
        top: "20px",
        left: "20px",
        // Changed to left to avoid overlapping with other extension buttons
        zIndex: "2147483647",
        // Max z-index
        padding: "10px 20px",
        borderRadius: "30px",
        cursor: "pointer",
        fontSize: "14px",
        display: "flex",
        backgroundColor: "rgba(15, 23, 42, 0.9)",
        border: "1px solid #38bdf8",
        pointerEvents: "auto"
        // Ensure clicks are captured
      });
      btn.onclick = async (e) => {
        e.stopPropagation();
        e.stopImmediatePropagation();
        e.preventDefault();
        console.log("Veritas-AI: Button clicked");
        if (this.analyzing) return;
        if (!this.consentGiven) {
          this.showConsentModal(video, btn);
        } else {
          await this.startAnalysis(video, btn);
        }
      };
      container.appendChild(btn);
      console.log("Veritas-AI: Button injected successfully");
    }
    handleExternalScan(message, sendResponse) {
      const video = document.querySelector("video");
      const btn = document.querySelector("#veritas-btn");
      const options = message.options || { enable_gemini: true };
      if (video && btn) {
        console.log("Veritas-AI: Scan triggered from popup", options);
        if (!this.analyzing) {
          if (!this.consentGiven) {
            this.showConsentModal(video, btn, options);
          } else {
            this.startAnalysis(video, btn, options);
          }
        }
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: "Video or button not found. Is the video playing?" });
      }
    }
    showConsentModal(video, btn, options = { enable_gemini: true }) {
      if (this.overlay) this.overlay.remove();
      this.overlay = document.createElement("div");
      this.overlay.className = "veritas-glass veritas-fade-in";
      Object.assign(this.overlay.style, {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "400px",
        padding: "24px",
        borderRadius: "16px",
        zIndex: "10000",
        textAlign: "left",
        pointerEvents: "auto"
      });
      this.overlay.innerHTML = `
      <h3 style="margin:0 0 12px 0; font-size: 18px; font-weight: 700;">Biometric Analysis Consent</h3>
      <p style="font-size: 14px; color: #cbd5e1; line-height: 1.5; margin-bottom: 20px;">
        To detect authenticity, Veritas-AI analyzes biological signals (pulse) from faces in this video. 
        This data is processed locally and via secure AI for forensic analysis only.
      </p>
      <div style="display: flex; gap: 10px; justify-content: flex-end;">
         <button id="veritas-cancel" style="padding: 8px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: transparent; color: white; cursor: pointer;">Cancel</button>
         <button id="veritas-agree" style="padding: 8px 16px; border-radius: 8px; background: #38bdf8; color: #0f172a; font-weight: 600; border: none; cursor: pointer;">I Agree</button>
      </div>
    `;
      const player = document.querySelector("#movie_player");
      player.appendChild(this.overlay);
      document.getElementById("veritas-cancel").onclick = (e) => {
        var _a;
        e.stopPropagation();
        e.stopImmediatePropagation();
        (_a = this.overlay) == null ? void 0 : _a.remove();
        this.overlay = null;
      };
      document.getElementById("veritas-agree").onclick = async (e) => {
        var _a;
        e.stopPropagation();
        e.stopImmediatePropagation();
        this.consentGiven = true;
        (_a = this.overlay) == null ? void 0 : _a.remove();
        this.overlay = null;
        await this.startAnalysis(video, btn, options);
      };
    }
    async startAnalysis(video, btn, options = { enable_gemini: true }) {
      try {
        this.analyzing = true;
        btn.innerHTML = `<span style="font-weight:600">Starting...</span>`;
        btn.style.opacity = "0.8";
        this.showScanningOverlay();
        const statusEl = document.getElementById("veritas-scan-status");
        if (statusEl) statusEl.textContent = "Acquiring Target...";
        const frameCount = 45;
        const intervalMs = 66;
        const fps = 1e3 / intervalMs;
        const frames = await this.veritasCapture.captureSequence(video, frameCount, intervalMs);
        if (frames.length === 0) throw new Error("Capture failed");
        if (statusEl) statusEl.textContent = "Processing Biometrics...";
        btn.innerHTML = `<span style="font-weight:600">Processing...</span>`;
        const response = await new Promise((resolve, reject) => {
          console.log("Veritas-AI: Sending ANALYZE_REQUEST with FPS:", fps);
          chrome.runtime.sendMessage({
            type: "ANALYZE_REQUEST",
            data: {
              frames,
              video_url: window.location.href,
              consent_given: true,
              enable_gemini: options.enable_gemini,
              fps
            }
          }, (responseCallback) => {
            console.log("Veritas-AI: Callback received", responseCallback, chrome.runtime.lastError);
            if (chrome.runtime.lastError) {
              console.error("Veritas-AI: Runtime error", chrome.runtime.lastError);
              reject(chrome.runtime.lastError);
            } else if (responseCallback && responseCallback.success) {
              resolve(responseCallback.result);
            } else {
              console.error("Veritas-AI: Success false", responseCallback);
              reject("Analysis failed: " + ((responseCallback == null ? void 0 : responseCallback.error) || "Unknown"));
            }
          });
        });
        this.showDetailedResult(response);
        btn.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <span style="font-weight: 700; color: #fff;">VERITAS</span>
      </div>`;
        btn.style.opacity = "1";
      } catch (e) {
        console.error(e);
        if (this.overlay) this.overlay.remove();
        let errorMessage = e.message || "Unknown error";
        if (errorMessage.includes("Extension context invalidated")) {
          errorMessage = "Extension updated. Please refresh this page.";
        }
        this.overlay = document.createElement("div");
        this.overlay.className = "veritas-glass veritas-fade-in";
        Object.assign(this.overlay.style, {
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "350px",
          padding: "24px",
          borderRadius: "16px",
          zIndex: "10000",
          textAlign: "center",
          border: "1px solid rgba(239, 68, 68, 0.4)"
        });
        this.overlay.innerHTML = `
        <div style="color: #ef4444; font-size: 48px; margin-bottom: 16px;">⚠️</div>
        <h3 style="margin: 0 0 8px 0; color: #ef4444;">Analysis Failed</h3>
        <p style="color: #cbd5e1; font-size: 13px; margin-bottom: 20px; word-break: break-word;">
           ${errorMessage}
        </p>
        <button id="veritas-error-close" style="padding: 8px 16px; background: rgba(255,255,255,0.1); border: none; border-radius: 8px; color: white; cursor: pointer;">Close</button>
      `;
        const player = document.querySelector("#movie_player");
        player.appendChild(this.overlay);
        document.getElementById("veritas-error-close").onclick = (ev) => {
          var _a;
          ev.stopPropagation();
          (_a = this.overlay) == null ? void 0 : _a.remove();
          this.overlay = null;
        };
        btn.innerHTML = `<span style="color:#ef4444; font-weight:700">Error</span>`;
        setTimeout(() => {
          btn.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span style="font-weight: 700; color: #fff;">VERITAS</span>
          </div>
        `;
        }, 3e3);
      } finally {
        this.analyzing = false;
      }
    }
    showScanningOverlay() {
      if (this.overlay) this.overlay.remove();
      this.overlay = document.createElement("div");
      this.overlay.className = "veritas-glass veritas-fade-in";
      Object.assign(this.overlay.style, {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "300px",
        padding: "24px",
        borderRadius: "20px",
        zIndex: "10000",
        textAlign: "center",
        pointerEvents: "none"
        // Let user watch video while scanning
      });
      this.overlay.innerHTML = `
        <div style="margin-bottom: 20px; position: relative;">
            <div style="width: 60px; height: 60px; border: 2px solid rgba(56, 189, 248, 0.1); border-top-color: #38bdf8; border-bottom-color: #38bdf8; border-radius: 50%; animation: veritas-spin 2s linear infinite; margin: 0 auto; box-shadow: 0 0 20px rgba(56, 189, 248, 0.2);"></div>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; background: rgba(56, 189, 248, 0.1); border-radius: 50%; animation: veritas-pulse-inner 1.5s ease-in-out infinite;"></div>
        </div>
        <div id="veritas-scan-status" style="font-family: 'Inter', monospace; font-size: 14px; color: #fff; font-weight: 600; letter-spacing: 2px; text-shadow: 0 0 10px rgba(56, 189, 248, 0.5);">INITIALIZING</div>
        <div style="font-size: 10px; color: #94a3b8; margin-top: 4px; letter-spacing: 0.5px;">ESTABLISHING SECURE CONNECTION</div>
        
        <div style="margin-top: 24px; height: 60px; width: 100%; overflow: hidden; position: relative; background: linear-gradient(90deg, transparent, rgba(56, 189, 248, 0.05), transparent); border-top: 1px solid rgba(56, 189, 248, 0.1); border-bottom: 1px solid rgba(56, 189, 248, 0.1);">
            <!-- High-tech waveform visualization -->
            <div style="display: flex; align-items: center; justify-content: center; gap: 4px; height: 100%; mask-image: linear-gradient(90deg, transparent, black 20%, black 80%, transparent);">
                ${Array.from({ length: 24 }).map((_, i) => `<div style="width: 3px; background: #38bdf8; border-radius: 10px; height: 10px; animation: veritas-wave 1s ease-in-out infinite; animation-delay: ${i * 0.05}s; box-shadow: 0 0 8px rgba(56, 189, 248, 0.4);"></div>`).join("")}
            </div>
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 1px; background: rgba(56, 189, 248, 0.3); box-shadow: 0 0 10px #38bdf8; animation: veritas-scanline 2s linear infinite;"></div>
        </div>
      `;
      if (!document.getElementById("veritas-keyframes")) {
        const style2 = document.createElement("style");
        style2.id = "veritas-keyframes";
        style2.textContent = `
            @keyframes veritas-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            @keyframes veritas-pulse-inner { 0%, 100% { transform: translate(-50%, -50%) scale(0.8); opacity: 0.5; } 50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.2; } }
            @keyframes veritas-wave { 0%, 100% { height: 10%; opacity: 0.3; } 50% { height: 70%; opacity: 1; } }
            @keyframes veritas-scanline { 0% { top: 0%; opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { top: 100%; opacity: 0; } }
          `;
        document.head.appendChild(style2);
      }
      const player = document.querySelector("#movie_player");
      player.appendChild(this.overlay);
    }
    showDetailedResult(result) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
      if (this.overlay) this.overlay.remove();
      const isReal = result.verdict === "LIKELY_REAL";
      const isFake = result.verdict === "LIKELY_FAKE";
      const color = isReal ? "#22c55e" : isFake ? "#ef4444" : "#eab308";
      const title = isReal ? "LIKELY REAL" : isFake ? "LIKELY FAKE" : "UNCERTAIN";
      const confidence = Math.round((result.confidence || 0) * 100);
      const evidenceList = (result.evidence || []).map((e) => {
        const isPositive = e.includes("✅") || e.includes("🔬") || e.includes("⏱️");
        const isNegative = e.includes("❌") || e.includes("🚨") || e.includes("⚠️");
        const color2 = isPositive ? "#22c55e" : isNegative ? "#ef4444" : "#e2e8f0";
        return `<li style="margin-bottom:8px; opacity:0.95; color:${color2}; font-size:13px; line-height:1.4;">${e}</li>`;
      }).join("");
      let graphHtml = "";
      if (((_a = result.bio_guard) == null ? void 0 : _a.pulse_signal) && result.bio_guard.pulse_signal.length > 10) {
        const data = result.bio_guard.pulse_signal;
        const min = Math.min(...data);
        const max = Math.max(...data);
        const range = max - min || 1;
        const points = data.map((v, i) => {
          const x = i / (data.length - 1) * 100;
          const y = 100 - (v - min) / range * 100;
          return `${x},${y}`;
        }).join(" ");
        graphHtml = `
        <div style="margin-top: 8px; width: 100%; height: 40px; background: rgba(0,0,0,0.2); border-radius: 6px; overflow: hidden; position: relative;">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width: 100%; height: 100%; opacity: 0.8;">
                <polyline points="${points}" fill="none" stroke="${result.bio_guard.pulse_detected ? "#22c55e" : "#94a3b8"}" stroke-width="2" vector-effect="non-scaling-stroke" />
            </svg>
             <div style="position:absolute; top:2px; left:4px; font-size:8px; color:rgba(255,255,255,0.4);">LIVE SIGNAL</div>
        </div>
        `;
      }
      this.overlay = document.createElement("div");
      this.overlay.className = "veritas-glass veritas-fade-in";
      Object.assign(this.overlay.style, {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "450px",
        padding: "0",
        borderRadius: "20px",
        zIndex: "10000",
        textAlign: "left",
        overflow: "hidden",
        pointerEvents: "auto"
      });
      const confidenceColor = confidence >= 85 ? "#22c55e" : confidence >= 70 ? "#3b82f6" : confidence >= 50 ? "#eab308" : "#ef4444";
      const confidenceLabel = confidence >= 90 ? "VERY HIGH" : confidence >= 80 ? "HIGH" : confidence >= 70 ? "MODERATE" : confidence >= 50 ? "LOW" : "VERY LOW";
      this.overlay.innerHTML = `
      <div style="padding: 24px; border-bottom: 1px solid rgba(255,255,255,0.1); background: linear-gradient(135deg, ${color}15 0%, transparent 100%);">
         <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
           <h2 style="margin:0; font-size: 28px; font-weight: 900; color: ${color}; letter-spacing: -0.5px; text-shadow: 0 2px 10px ${color}40;">${title}</h2>
         </div>
         <div style="display: flex; align-items: center; gap: 16px;">
           <div style="flex: 1;">
             <div style="font-size: 11px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.6; margin-bottom: 4px;">Confidence Level</div>
             <div style="display: flex; align-items: center; gap: 8px;">
               <div style="flex: 1; height: 8px; background: rgba(255,255,255,0.1); border-radius: 4px; overflow: hidden;">
                 <div style="height: 100%; width: ${confidence}%; background: linear-gradient(90deg, ${confidenceColor} 0%, ${confidenceColor}dd 100%); border-radius: 4px; transition: width 0.5s;"></div>
               </div>
               <div style="font-family: monospace; font-size: 18px; font-weight: 700; color: ${confidenceColor}; min-width: 50px; text-align: right;">${confidence}%</div>
             </div>
             <div style="font-size: 10px; color: ${confidenceColor}; margin-top: 4px; font-weight: 600;">${confidenceLabel} CONFIDENCE</div>
           </div>
         </div>
      </div>
      
      <div style="padding: 24px; background: rgba(0,0,0,0.2);">
        <h4 style="margin:0 0 12px 0; font-size: 12px; text-transform:uppercase; letter-spacing:1px; opacity:0.6;">Forensic Analysis</h4>
        <ul style="margin:0; padding-left: 20px; font-size: 14px; line-height: 1.5; color: #e2e8f0;">
          ${evidenceList}
        </ul>
        
        <div style="margin-top: 20px; display:grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
            <div style="background: linear-gradient(135deg, rgba(56, 189, 248, 0.1) 0%, rgba(56, 189, 248, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">BIO-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${((_b = result.bio_guard) == null ? void 0 : _b.pulse_detected) ? "#22c55e" : ((_c = result.bio_guard) == null ? void 0 : _c.is_synthetic) ? "#ef4444" : "#94a3b8"}; margin-bottom:4px;">
               ${((_d = result.bio_guard) == null ? void 0 : _d.is_synthetic) ? "⚠️ Synthetic Pattern" : ((_e = result.bio_guard) == null ? void 0 : _e.pulse_detected) ? `❤️ ${Math.round(result.bio_guard.bpm)} BPM` : "❌ No Pulse"}
             </div>
             ${((_f = result.bio_guard) == null ? void 0 : _f.snr) ? `<div style="font-size:11px; opacity:0.7; color:${result.bio_guard.snr > 15 || result.bio_guard.snr < 2 ? "#ef4444" : result.bio_guard.snr > 5 ? "#22c55e" : "#eab308"};">SNR: ${result.bio_guard.snr.toFixed(1)} ${result.bio_guard.snr > 20 ? "(Suspicious)" : ""}</div>` : ""}
             ${graphHtml}
           </div>
           <div style="background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">PHYSICS-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${((_g = result.physics_guard) == null ? void 0 : _g.is_suspicious) ? "#ef4444" : ((_h = result.physics_guard) == null ? void 0 : _h.is_real) ? "#22c55e" : "#94a3b8"}; margin-bottom:4px;">
               ${((_i = result.physics_guard) == null ? void 0 : _i.is_real) ? "✅ Authentic" : ((_j = result.physics_guard) == null ? void 0 : _j.is_suspicious) ? "❌ Synthetic" : "⚠️ Uncertain"}
             </div>
             ${((_k = result.physics_guard) == null ? void 0 : _k.confidence) ? `<div style="font-size:11px; opacity:0.7;">Conf: ${Math.round(result.physics_guard.confidence * 100)}%</div>` : ""}
           </div>
           ${((_l = result.temporal_guard) == null ? void 0 : _l.available) ? `
           <div style="background: linear-gradient(135deg, rgba(236, 72, 153, 0.1) 0%, rgba(236, 72, 153, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(236, 72, 153, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">TEMPORAL-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${result.temporal_guard.temporal_consistency > 0.7 ? "#22c55e" : result.temporal_guard.temporal_consistency < 0.4 ? "#ef4444" : "#eab308"}; margin-bottom:4px;">
               ${result.temporal_guard.temporal_consistency > 0.7 ? "✅ Consistent" : result.temporal_guard.temporal_consistency < 0.4 ? "❌ Inconsistent" : "⚠️ Moderate"}
             </div>
             <div style="font-size:11px; opacity:0.7;">Score: ${(result.temporal_guard.temporal_consistency * 100).toFixed(0)}%</div>
           </div>
           ` : ""}
        </div>
        
        ${result.summary ? `
        <div style="margin-top: 16px; padding: 12px; background: rgba(56, 189, 248, 0.1); border-left: 3px solid #38bdf8; border-radius: 8px;">
          <div style="font-size:12px; font-weight:600; margin-bottom:6px; color:#38bdf8;">SUMMARY</div>
          <div style="font-size:13px; color:#e2e8f0; line-height:1.5;">${result.summary}</div>
        </div>
        ` : ""}
      </div>
      
      <div style="padding: 16px; background: rgba(0,0,0,0.4); text-align:center;">
        <button id="veritas-close" style="background: transparent; border: none; color: #94a3b8; font-size: 13px; cursor: pointer; text-decoration: underline;">Close Analysis</button>
      </div>
    `;
      const player = document.querySelector("#movie_player");
      player.appendChild(this.overlay);
      document.getElementById("veritas-close").onclick = (e) => {
        var _a2;
        e.stopPropagation();
        e.stopImmediatePropagation();
        (_a2 = this.overlay) == null ? void 0 : _a2.remove();
        this.overlay = null;
      };
    }
  }
  const initVeritas = () => {
    if (window.veritasInitialized) return;
    window.veritasInitialized = true;
    console.log("Veritas-AI: Initializing Core...");
    const core = new VeritasCore();
    chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
      if (request.type === "START_SCAN") {
        core.handleExternalScan(request, sendResponse);
        return true;
      }
    });
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initVeritas);
  } else {
    initVeritas();
  }
})();
