var V=Object.defineProperty;var F=(p,e,t)=>e in p?V(p,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):p[e]=t;var h=(p,e,t)=>F(p,typeof e!="symbol"?e+"":e,t);class P{constructor(){h(this,"canvas");h(this,"ctx");this.canvas=document.createElement("canvas"),this.ctx=this.canvas.getContext("2d")}async captureFrame(e){const t=this.captureFrameDirect(e);return t||await this.captureFrameFallback(e)}captureFrameDirect(e){if(!this.ctx||e.videoWidth===0||e.videoHeight===0)return null;const t=e.videoWidth,i=e.videoHeight,a=640;let o=t,n=i;if(t>a||i>a){const r=Math.min(a/t,a/i);o=Math.round(t*r),n=Math.round(i*r)}this.canvas.width=o,this.canvas.height=n;try{return this.ctx.drawImage(e,0,0,o,n),{data:this.canvas.toDataURL("image/jpeg",.8).split(",")[1],timestamp:e.currentTime}}catch{return null}}async captureFrameFallback(e){return new Promise(t=>{chrome.runtime.sendMessage({type:"CAPTURE_TAB"},async i=>{if(!i||!i.success){t(null);return}const a=e.getBoundingClientRect();try{const o=await fetch(i.dataUrl).then(s=>s.blob()),n=await createImageBitmap(o),r=window.devicePixelRatio||1;if(this.canvas.width=640,this.canvas.height=360,this.ctx){this.ctx.drawImage(n,a.left*r,a.top*r,a.width*r,a.height*r,0,0,this.canvas.width,this.canvas.height);const s=this.canvas.toDataURL("image/jpeg",.8);t({data:s.split(",")[1],timestamp:e.currentTime})}else t(null)}catch(o){console.error("Fallback crop failed",o),t(null)}})})}async captureSequence(e,t=30,i=100){const a=[],o=this.captureFrameDirect(e),n=!o;o&&a.push(o);const r=n?Math.max(i,300):i;for(let s=0;s<t;s++){if(n){const d=await this.captureFrameFallback(e);d&&a.push(d)}else if(s>0){const d=this.captureFrameDirect(e);d&&a.push(d)}s<t-1&&await new Promise(d=>setTimeout(d,r))}return a}}console.log("Veritas-AI: Content script loaded");const M=document.createElement("style");M.textContent=`
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

  .veritas-glass {
    background: rgba(15, 23, 42, 0.85);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.5);
    font-family: 'Inter', sans-serif;
    color: white;
  }
  
  .veritas-btn-pulse {
    animation: veritas-pulse 3s infinite;
  }
  
  @keyframes veritas-pulse {
    0% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0.4); }
    70% { box-shadow: 0 0 0 10px rgba(56, 189, 248, 0); }
    100% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0); }
  }

  .veritas-fade-in {
    animation: veritas-fade-in 0.3s ease-out forwards;
  }

  @keyframes veritas-fade-in {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;document.head.appendChild(M);class N{constructor(){h(this,"veritasCapture");h(this,"analyzing",!1);h(this,"overlay",null);h(this,"consentGiven",!1);this.veritasCapture=new P,this.init()}init(){console.log("Veritas-AI: Init called"),setInterval(()=>{this.checkForVideo()},1e3),new MutationObserver(()=>{this.checkForVideo()}).observe(document.body,{childList:!0,subtree:!0})}checkForVideo(){const e=document.querySelector("video"),t=document.querySelector("#movie_player")||document.querySelector("#ytd-player");e&&t&&!document.querySelector("#veritas-btn")&&(console.log("Veritas-AI: Player found, injecting button..."),this.injectButton(t,e))}injectButton(e,t){if(document.querySelector("#veritas-btn"))return;const i=document.createElement("button");i.id="veritas-btn",i.className="veritas-glass veritas-btn-pulse",i.innerHTML=`
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <span style="font-weight: 700; color: #fff; letter-spacing: 0.5px;">VERITAS SEAL</span>
      </div>
    `,Object.assign(i.style,{position:"absolute",top:"20px",left:"20px",zIndex:"2147483647",padding:"10px 20px",borderRadius:"30px",cursor:"pointer",fontSize:"14px",display:"flex",backgroundColor:"rgba(15, 23, 42, 0.9)",border:"1px solid #38bdf8",pointerEvents:"auto"}),i.onclick=async a=>{a.stopPropagation(),a.stopImmediatePropagation(),a.preventDefault(),console.log("Veritas-AI: Button clicked"),!this.analyzing&&(this.consentGiven?await this.startAnalysis(t,i):this.showConsentModal(t,i))},e.appendChild(i),console.log("Veritas-AI: Button injected successfully")}handleExternalScan(e,t){const i=document.querySelector("video"),a=document.querySelector("#veritas-btn"),o=e.options||{enable_gemini:!0};i&&a?(console.log("Veritas-AI: Scan triggered from popup",o),this.analyzing||(this.consentGiven?this.startAnalysis(i,a,o):this.showConsentModal(i,a,o)),t({success:!0})):t({success:!1,error:"Video or button not found. Is the video playing?"})}showConsentModal(e,t,i={enable_gemini:!0}){this.overlay&&this.overlay.remove(),this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"400px",padding:"24px",borderRadius:"16px",zIndex:"10000",textAlign:"left",pointerEvents:"auto"}),this.overlay.innerHTML=`
      <h3 style="margin:0 0 12px 0; font-size: 18px; font-weight: 700;">Biometric Analysis Consent</h3>
      <p style="font-size: 14px; color: #cbd5e1; line-height: 1.5; margin-bottom: 20px;">
        To detect authenticity, Veritas-AI analyzes biological signals (pulse) from faces in this video. 
        This data is processed locally and via secure AI for forensic analysis only.
      </p>
      <div style="display: flex; gap: 10px; justify-content: flex-end;">
         <button id="veritas-cancel" style="padding: 8px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: transparent; color: white; cursor: pointer;">Cancel</button>
         <button id="veritas-agree" style="padding: 8px 16px; border-radius: 8px; background: #38bdf8; color: #0f172a; font-weight: 600; border: none; cursor: pointer;">I Agree</button>
      </div>
    `,document.querySelector("#movie_player").appendChild(this.overlay),document.getElementById("veritas-cancel").onclick=o=>{var n;o.stopPropagation(),o.stopImmediatePropagation(),(n=this.overlay)==null||n.remove(),this.overlay=null},document.getElementById("veritas-agree").onclick=async o=>{var n;o.stopPropagation(),o.stopImmediatePropagation(),this.consentGiven=!0,(n=this.overlay)==null||n.remove(),this.overlay=null,await this.startAnalysis(e,t,i)}}async startAnalysis(e,t,i={enable_gemini:!0}){try{this.analyzing=!0,t.innerHTML='<span style="font-weight:600">Starting...</span>',t.style.opacity="0.8",this.showScanningOverlay();const a=document.getElementById("veritas-scan-status");a&&(a.textContent="Acquiring Target...");const o=45,n=66,r=1e3/n,s=await this.veritasCapture.captureSequence(e,o,n);if(s.length===0)throw new Error("Capture failed");a&&(a.textContent="Processing Biometrics..."),t.innerHTML='<span style="font-weight:600">Processing...</span>';const d=await new Promise((v,m)=>{console.log("Veritas-AI: Sending ANALYZE_REQUEST with FPS:",r),chrome.runtime.sendMessage({type:"ANALYZE_REQUEST",data:{frames:s,video_url:window.location.href,consent_given:!0,enable_gemini:i.enable_gemini,fps:r}},c=>{console.log("Veritas-AI: Callback received",c,chrome.runtime.lastError),chrome.runtime.lastError?(console.error("Veritas-AI: Runtime error",chrome.runtime.lastError),m(chrome.runtime.lastError)):c&&c.success?v(c.result):(console.error("Veritas-AI: Success false",c),m("Analysis failed: "+((c==null?void 0:c.error)||"Unknown")))})});this.showDetailedResult(d),t.innerHTML=`
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <span style="font-weight: 700; color: #fff;">VERITAS</span>
      </div>`,t.style.opacity="1"}catch(a){console.error(a),this.overlay&&this.overlay.remove();let o=a.message||"Unknown error";o.includes("Extension context invalidated")&&(o="Extension updated. Please refresh this page."),this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"350px",padding:"24px",borderRadius:"16px",zIndex:"10000",textAlign:"center",border:"1px solid rgba(239, 68, 68, 0.4)"}),this.overlay.innerHTML=`
        <div style="color: #ef4444; font-size: 48px; margin-bottom: 16px;">⚠️</div>
        <h3 style="margin: 0 0 8px 0; color: #ef4444;">Analysis Failed</h3>
        <p style="color: #cbd5e1; font-size: 13px; margin-bottom: 20px; word-break: break-word;">
           ${o}
        </p>
        <button id="veritas-error-close" style="padding: 8px 16px; background: rgba(255,255,255,0.1); border: none; border-radius: 8px; color: white; cursor: pointer;">Close</button>
      `,document.querySelector("#movie_player").appendChild(this.overlay),document.getElementById("veritas-error-close").onclick=r=>{var s;r.stopPropagation(),(s=this.overlay)==null||s.remove(),this.overlay=null},t.innerHTML='<span style="color:#ef4444; font-weight:700">Error</span>',setTimeout(()=>{t.innerHTML=`
          <div style="display: flex; align-items: center; gap: 8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span style="font-weight: 700; color: #fff;">VERITAS</span>
          </div>
        `},3e3)}finally{this.analyzing=!1}}showScanningOverlay(){if(this.overlay&&this.overlay.remove(),this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"300px",padding:"24px",borderRadius:"20px",zIndex:"10000",textAlign:"center",pointerEvents:"none"}),this.overlay.innerHTML=`
        <div style="margin-bottom: 20px; position: relative;">
            <div style="width: 60px; height: 60px; border: 2px solid rgba(56, 189, 248, 0.1); border-top-color: #38bdf8; border-bottom-color: #38bdf8; border-radius: 50%; animation: veritas-spin 2s linear infinite; margin: 0 auto; box-shadow: 0 0 20px rgba(56, 189, 248, 0.2);"></div>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; background: rgba(56, 189, 248, 0.1); border-radius: 50%; animation: veritas-pulse-inner 1.5s ease-in-out infinite;"></div>
        </div>
        <div id="veritas-scan-status" style="font-family: 'Inter', monospace; font-size: 14px; color: #fff; font-weight: 600; letter-spacing: 2px; text-shadow: 0 0 10px rgba(56, 189, 248, 0.5);">INITIALIZING</div>
        <div style="font-size: 10px; color: #94a3b8; margin-top: 4px; letter-spacing: 0.5px;">ESTABLISHING SECURE CONNECTION</div>
        
        <div style="margin-top: 24px; height: 60px; width: 100%; overflow: hidden; position: relative; background: linear-gradient(90deg, transparent, rgba(56, 189, 248, 0.05), transparent); border-top: 1px solid rgba(56, 189, 248, 0.1); border-bottom: 1px solid rgba(56, 189, 248, 0.1);">
            <!-- High-tech waveform visualization -->
            <div style="display: flex; align-items: center; justify-content: center; gap: 4px; height: 100%; mask-image: linear-gradient(90deg, transparent, black 20%, black 80%, transparent);">
                ${Array.from({length:24}).map((t,i)=>`<div style="width: 3px; background: #38bdf8; border-radius: 10px; height: 10px; animation: veritas-wave 1s ease-in-out infinite; animation-delay: ${i*.05}s; box-shadow: 0 0 8px rgba(56, 189, 248, 0.4);"></div>`).join("")}
            </div>
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 1px; background: rgba(56, 189, 248, 0.3); box-shadow: 0 0 10px #38bdf8; animation: veritas-scanline 2s linear infinite;"></div>
        </div>
      `,!document.getElementById("veritas-keyframes")){const t=document.createElement("style");t.id="veritas-keyframes",t.textContent=`
            @keyframes veritas-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            @keyframes veritas-pulse-inner { 0%, 100% { transform: translate(-50%, -50%) scale(0.8); opacity: 0.5; } 50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.2; } }
            @keyframes veritas-wave { 0%, 100% { height: 10%; opacity: 0.3; } 50% { height: 70%; opacity: 1; } }
            @keyframes veritas-scanline { 0% { top: 0%; opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { top: 100%; opacity: 0; } }
          `,document.head.appendChild(t)}document.querySelector("#movie_player").appendChild(this.overlay)}showDetailedResult(e){var c,u,y,f,x,b,w,I,_,E,A,k;this.overlay&&this.overlay.remove();const t=e.verdict==="LIKELY_REAL",i=e.verdict==="LIKELY_FAKE",a=t?"#22c55e":i?"#ef4444":"#eab308",o=t?"LIKELY REAL":i?"LIKELY FAKE":"UNCERTAIN",n=Math.round((e.confidence||0)*100),r=(e.evidence||[]).map(l=>{const g=l.includes("✅")||l.includes("🔬")||l.includes("⏱️"),z=l.includes("❌")||l.includes("🚨")||l.includes("⚠️");return`<li style="margin-bottom:8px; opacity:0.95; color:${g?"#22c55e":z?"#ef4444":"#e2e8f0"}; font-size:13px; line-height:1.4;">${l}</li>`}).join("");let s="";if((c=e.bio_guard)!=null&&c.pulse_signal&&e.bio_guard.pulse_signal.length>10){const l=e.bio_guard.pulse_signal,g=Math.min(...l),S=Math.max(...l)-g||1;s=`
        <div style="margin-top: 8px; width: 100%; height: 40px; background: rgba(0,0,0,0.2); border-radius: 6px; overflow: hidden; position: relative;">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width: 100%; height: 100%; opacity: 0.8;">
                <polyline points="${l.map(($,C)=>{const R=C/(l.length-1)*100,T=100-($-g)/S*100;return`${R},${T}`}).join(" ")}" fill="none" stroke="${e.bio_guard.pulse_detected?"#22c55e":"#94a3b8"}" stroke-width="2" vector-effect="non-scaling-stroke" />
            </svg>
             <div style="position:absolute; top:2px; left:4px; font-size:8px; color:rgba(255,255,255,0.4);">LIVE SIGNAL</div>
        </div>
        `}this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"450px",padding:"0",borderRadius:"20px",zIndex:"10000",textAlign:"left",overflow:"hidden",pointerEvents:"auto"});const d=n>=85?"#22c55e":n>=70?"#3b82f6":n>=50?"#eab308":"#ef4444",v=n>=90?"VERY HIGH":n>=80?"HIGH":n>=70?"MODERATE":n>=50?"LOW":"VERY LOW";this.overlay.innerHTML=`
      <div style="padding: 24px; border-bottom: 1px solid rgba(255,255,255,0.1); background: linear-gradient(135deg, ${a}15 0%, transparent 100%);">
         <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
           <h2 style="margin:0; font-size: 28px; font-weight: 900; color: ${a}; letter-spacing: -0.5px; text-shadow: 0 2px 10px ${a}40;">${o}</h2>
         </div>
         <div style="display: flex; align-items: center; gap: 16px;">
           <div style="flex: 1;">
             <div style="font-size: 11px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.6; margin-bottom: 4px;">Confidence Level</div>
             <div style="display: flex; align-items: center; gap: 8px;">
               <div style="flex: 1; height: 8px; background: rgba(255,255,255,0.1); border-radius: 4px; overflow: hidden;">
                 <div style="height: 100%; width: ${n}%; background: linear-gradient(90deg, ${d} 0%, ${d}dd 100%); border-radius: 4px; transition: width 0.5s;"></div>
               </div>
               <div style="font-family: monospace; font-size: 18px; font-weight: 700; color: ${d}; min-width: 50px; text-align: right;">${n}%</div>
             </div>
             <div style="font-size: 10px; color: ${d}; margin-top: 4px; font-weight: 600;">${v} CONFIDENCE</div>
           </div>
         </div>
      </div>
      
      <div style="padding: 24px; background: rgba(0,0,0,0.2);">
        <h4 style="margin:0 0 12px 0; font-size: 12px; text-transform:uppercase; letter-spacing:1px; opacity:0.6;">Forensic Analysis</h4>
        <ul style="margin:0; padding-left: 20px; font-size: 14px; line-height: 1.5; color: #e2e8f0;">
          ${r}
        </ul>
        
        <div style="margin-top: 20px; display:grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
            <div style="background: linear-gradient(135deg, rgba(56, 189, 248, 0.1) 0%, rgba(56, 189, 248, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">BIO-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${(u=e.bio_guard)!=null&&u.pulse_detected?"#22c55e":(y=e.bio_guard)!=null&&y.is_synthetic?"#ef4444":"#94a3b8"}; margin-bottom:4px;">
               ${(f=e.bio_guard)!=null&&f.is_synthetic?"⚠️ Synthetic Pattern":(x=e.bio_guard)!=null&&x.pulse_detected?`❤️ ${Math.round(e.bio_guard.bpm)} BPM`:"❌ No Pulse"}
             </div>
             ${(b=e.bio_guard)!=null&&b.snr?`<div style="font-size:11px; opacity:0.7; color:${e.bio_guard.snr>15||e.bio_guard.snr<2?"#ef4444":e.bio_guard.snr>5?"#22c55e":"#eab308"};">SNR: ${e.bio_guard.snr.toFixed(1)} ${e.bio_guard.snr>20?"(Suspicious)":""}</div>`:""}
             ${s}
           </div>
           <div style="background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">PHYSICS-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${(w=e.physics_guard)!=null&&w.is_suspicious?"#ef4444":(I=e.physics_guard)!=null&&I.is_real?"#22c55e":"#94a3b8"}; margin-bottom:4px;">
               ${(_=e.physics_guard)!=null&&_.is_real?"✅ Authentic":(E=e.physics_guard)!=null&&E.is_suspicious?"❌ Synthetic":"⚠️ Uncertain"}
             </div>
             ${(A=e.physics_guard)!=null&&A.confidence?`<div style="font-size:11px; opacity:0.7;">Conf: ${Math.round(e.physics_guard.confidence*100)}%</div>`:""}
           </div>
           ${(k=e.temporal_guard)!=null&&k.available?`
           <div style="background: linear-gradient(135deg, rgba(236, 72, 153, 0.1) 0%, rgba(236, 72, 153, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(236, 72, 153, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">TEMPORAL-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${e.temporal_guard.temporal_consistency>.7?"#22c55e":e.temporal_guard.temporal_consistency<.4?"#ef4444":"#eab308"}; margin-bottom:4px;">
               ${e.temporal_guard.temporal_consistency>.7?"✅ Consistent":e.temporal_guard.temporal_consistency<.4?"❌ Inconsistent":"⚠️ Moderate"}
             </div>
             <div style="font-size:11px; opacity:0.7;">Score: ${(e.temporal_guard.temporal_consistency*100).toFixed(0)}%</div>
           </div>
           `:""}
        </div>
        
        ${e.summary?`
        <div style="margin-top: 16px; padding: 12px; background: rgba(56, 189, 248, 0.1); border-left: 3px solid #38bdf8; border-radius: 8px;">
          <div style="font-size:12px; font-weight:600; margin-bottom:6px; color:#38bdf8;">SUMMARY</div>
          <div style="font-size:13px; color:#e2e8f0; line-height:1.5;">${e.summary}</div>
        </div>
        `:""}
      </div>
      
      <div style="padding: 16px; background: rgba(0,0,0,0.4); text-align:center;">
        <button id="veritas-close" style="background: transparent; border: none; color: #94a3b8; font-size: 13px; cursor: pointer; text-decoration: underline;">Close Analysis</button>
      </div>
    `,document.querySelector("#movie_player").appendChild(this.overlay),document.getElementById("veritas-close").onclick=l=>{var g;l.stopPropagation(),l.stopImmediatePropagation(),(g=this.overlay)==null||g.remove(),this.overlay=null}}}const L=()=>{if(window.veritasInitialized)return;window.veritasInitialized=!0,console.log("Veritas-AI: Initializing Core...");const p=new N;chrome.runtime.onMessage.addListener((e,t,i)=>{if(e.type==="START_SCAN")return p.handleExternalScan(e,i),!0})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",L):L();
