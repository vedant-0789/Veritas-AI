var T=Object.defineProperty;var F=(p,c,v)=>c in p?T(p,c,{enumerable:!0,configurable:!0,writable:!0,value:v}):p[c]=v;var h=(p,c,v)=>F(p,typeof c!="symbol"?c+"":c,v);(function(){"use strict";class p{constructor(){h(this,"canvas");h(this,"ctx");this.canvas=document.createElement("canvas"),this.ctx=this.canvas.getContext("2d")}async captureFrame(e){const t=this.captureFrameDirect(e);return t||await this.captureFrameFallback(e)}captureFrameDirect(e){if(!this.ctx||e.videoWidth===0||e.videoHeight===0)return null;const t=e.videoWidth,a=e.videoHeight,i=640;let o=t,n=a;if(t>i||a>i){const s=Math.min(i/t,i/a);o=Math.round(t*s),n=Math.round(a*s)}this.canvas.width=o,this.canvas.height=n;try{return this.ctx.drawImage(e,0,0,o,n),{data:this.canvas.toDataURL("image/jpeg",.8).split(",")[1],timestamp:e.currentTime}}catch{return null}}async captureFrameFallback(e){return new Promise(t=>{chrome.runtime.sendMessage({type:"CAPTURE_TAB"},async a=>{if(!a||!a.success){t(null);return}const i=e.getBoundingClientRect();try{const o=await fetch(a.dataUrl).then(r=>r.blob()),n=await createImageBitmap(o),s=window.devicePixelRatio||1;if(this.canvas.width=640,this.canvas.height=360,this.ctx){this.ctx.drawImage(n,i.left*s,i.top*s,i.width*s,i.height*s,0,0,this.canvas.width,this.canvas.height);const r=this.canvas.toDataURL("image/jpeg",.8);t({data:r.split(",")[1],timestamp:e.currentTime})}else t(null)}catch(o){console.error("Fallback crop failed",o),t(null)}})})}async captureSequence(e,t=30,a=100){const i=[],o=this.captureFrameDirect(e),n=!o;o&&i.push(o);const s=n?Math.max(a,300):a;for(let r=0;r<t;r++){if(n){const l=await this.captureFrameFallback(e);l&&i.push(l)}else if(r>0){const l=this.captureFrameDirect(e);l&&i.push(l)}r<t-1&&await new Promise(l=>setTimeout(l,s))}return i}}console.log("Veritas-AI: Content script loaded");const c=document.createElement("style");c.textContent=`
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

  .veritas-glass {
    background: rgba(15, 23, 42, 0.85);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.5);
    font-family: 'Inter', sans-serif;
    color: white;
  }
  
  .veritas-btn-pulse {
    animation: veritas-pulse 3s infinite;
  }
  
  @keyframes veritas-pulse {
    0% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0.4); }
    70% { box-shadow: 0 0 0 10px rgba(56, 189, 248, 0); }
    100% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0); }
  }

  .veritas-fade-in {
    animation: veritas-fade-in 0.3s ease-out forwards;
  }

  @keyframes veritas-fade-in {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`,document.head.appendChild(c);class v{constructor(){h(this,"videoCapture");h(this,"analyzing",!1);h(this,"overlay",null);h(this,"consentGiven",!1);this.videoCapture=new p,this.init()}init(){console.log("Veritas-AI: Init called"),setInterval(()=>{this.checkForVideo()},1e3),new MutationObserver(()=>{this.checkForVideo()}).observe(document.body,{childList:!0,subtree:!0})}checkForVideo(){const e=document.querySelector("video"),t=document.querySelector("#movie_player")||document.querySelector("#ytd-player");e&&t&&!document.querySelector("#veritas-btn")&&(console.log("Veritas-AI: Player found, injecting button..."),this.injectButton(t,e))}injectButton(e,t){if(document.querySelector("#veritas-btn"))return;const a=document.createElement("button");a.id="veritas-btn",a.className="veritas-glass veritas-btn-pulse",a.innerHTML=`
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <span style="font-weight: 700; color: #fff; letter-spacing: 0.5px;">VERITAS SEAL</span>
      </div>
    `,Object.assign(a.style,{position:"absolute",top:"20px",left:"20px",zIndex:"2147483647",padding:"10px 20px",borderRadius:"30px",cursor:"pointer",fontSize:"14px",display:"flex",backgroundColor:"rgba(15, 23, 42, 0.9)",border:"1px solid #38bdf8",pointerEvents:"auto"}),a.onclick=async i=>{i.stopPropagation(),i.stopImmediatePropagation(),i.preventDefault(),console.log("Veritas-AI: Button clicked"),!this.analyzing&&(this.consentGiven?await this.startAnalysis(t,a):this.showConsentModal(t,a))},e.appendChild(a),console.log("Veritas-AI: Button injected successfully")}handleExternalScan(e,t){const a=document.querySelector("video"),i=document.querySelector("#veritas-btn"),o=e.options||{enable_gemini:!0};a&&i?(console.log("Veritas-AI: Scan triggered from popup",o),this.analyzing||(this.consentGiven?this.startAnalysis(a,i,o):this.showConsentModal(a,i,o)),t({success:!0})):t({success:!1,error:"Video or button not found. Is the video playing?"})}showConsentModal(e,t,a={enable_gemini:!0}){this.overlay&&this.overlay.remove(),this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"400px",padding:"24px",borderRadius:"16px",zIndex:"10000",textAlign:"left",pointerEvents:"auto"}),this.overlay.innerHTML=`
      <h3 style="margin:0 0 12px 0; font-size: 18px; font-weight: 700;">Biometric Analysis Consent</h3>
      <p style="font-size: 14px; color: #cbd5e1; line-height: 1.5; margin-bottom: 20px;">
        To detect authenticity, Veritas-AI analyzes biological signals (pulse) from faces in this video. 
        This data is processed locally and via secure AI for forensic analysis only.
      </p>
      <div style="display: flex; gap: 10px; justify-content: flex-end;">
         <button id="veritas-cancel" style="padding: 8px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: transparent; color: white; cursor: pointer;">Cancel</button>
         <button id="veritas-agree" style="padding: 8px 16px; border-radius: 8px; background: #38bdf8; color: #0f172a; font-weight: 600; border: none; cursor: pointer;">I Agree</button>
      </div>
    `,document.querySelector("#movie_player").appendChild(this.overlay),document.getElementById("veritas-cancel").onclick=o=>{var n;o.stopPropagation(),o.stopImmediatePropagation(),(n=this.overlay)==null||n.remove(),this.overlay=null},document.getElementById("veritas-agree").onclick=async o=>{var n;o.stopPropagation(),o.stopImmediatePropagation(),this.consentGiven=!0,(n=this.overlay)==null||n.remove(),this.overlay=null,await this.startAnalysis(e,t,a)}}async startAnalysis(e,t,a={enable_gemini:!0}){try{this.analyzing=!0,t.innerHTML='<span style="font-weight:600">Starting...</span>',t.style.opacity="0.8",this.showScanningOverlay();const i=document.getElementById("veritas-scan-status");i&&(i.textContent="Acquiring Target...");const o=await this.videoCapture.captureSequence(e,15,150);if(o.length===0)throw new Error("Capture failed");i&&(i.textContent="Processing Biometrics..."),t.innerHTML='<span style="font-weight:600">Processing...</span>';const n=await new Promise((s,r)=>{chrome.runtime.sendMessage({type:"ANALYZE_REQUEST",data:{frames:o,video_url:window.location.href,consent_given:!0,enable_gemini:a.enable_gemini}},l=>{chrome.runtime.lastError?r(chrome.runtime.lastError):l.success?s(l.result):r(new Error(l.error||"Analysis failed"))})});this.showDetailedResult(n),t.innerHTML=`
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <span style="font-weight: 700; color: #fff;">VERITAS</span>
      </div>`,t.style.opacity="1"}catch(i){console.error(i),this.overlay&&this.overlay.remove();let o=i.message||"Unknown error";o.includes("Extension context invalidated")&&(o="Extension updated. Please refresh this page."),this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"350px",padding:"24px",borderRadius:"16px",zIndex:"10000",textAlign:"center",border:"1px solid rgba(239, 68, 68, 0.4)"}),this.overlay.innerHTML=`
        <div style="color: #ef4444; font-size: 48px; margin-bottom: 16px;">⚠️</div>
        <h3 style="margin: 0 0 8px 0; color: #ef4444;">Analysis Failed</h3>
        <p style="color: #cbd5e1; font-size: 13px; margin-bottom: 20px; word-break: break-word;">
           ${o}
        </p>
        <button id="veritas-error-close" style="padding: 8px 16px; background: rgba(255,255,255,0.1); border: none; border-radius: 8px; color: white; cursor: pointer;">Close</button>
      `,document.querySelector("#movie_player").appendChild(this.overlay),document.getElementById("veritas-error-close").onclick=s=>{var r;s.stopPropagation(),(r=this.overlay)==null||r.remove(),this.overlay=null},t.innerHTML='<span style="color:#ef4444; font-weight:700">Error</span>',setTimeout(()=>{t.innerHTML=`
          <div style="display: flex; align-items: center; gap: 8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span style="font-weight: 700; color: #fff;">VERITAS</span>
          </div>
        `},3e3)}finally{this.analyzing=!1}}showScanningOverlay(){if(this.overlay&&this.overlay.remove(),this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"300px",padding:"24px",borderRadius:"20px",zIndex:"10000",textAlign:"center",pointerEvents:"none"}),this.overlay.innerHTML=`
        <div style="margin-bottom: 20px; position: relative;">
            <div style="width: 60px; height: 60px; border: 2px solid rgba(56, 189, 248, 0.1); border-top-color: #38bdf8; border-bottom-color: #38bdf8; border-radius: 50%; animation: veritas-spin 2s linear infinite; margin: 0 auto; box-shadow: 0 0 20px rgba(56, 189, 248, 0.2);"></div>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; background: rgba(56, 189, 248, 0.1); border-radius: 50%; animation: veritas-pulse-inner 1.5s ease-in-out infinite;"></div>
        </div>
        <div id="veritas-scan-status" style="font-family: 'Inter', monospace; font-size: 14px; color: #fff; font-weight: 600; letter-spacing: 2px; text-shadow: 0 0 10px rgba(56, 189, 248, 0.5);">INITIALIZING</div>
        <div style="font-size: 10px; color: #94a3b8; margin-top: 4px; letter-spacing: 0.5px;">ESTABLISHING SECURE CONNECTION</div>
        
        <div style="margin-top: 24px; height: 60px; width: 100%; overflow: hidden; position: relative; background: linear-gradient(90deg, transparent, rgba(56, 189, 248, 0.05), transparent); border-top: 1px solid rgba(56, 189, 248, 0.1); border-bottom: 1px solid rgba(56, 189, 248, 0.1);">
            <!-- High-tech waveform visualization -->
            <div style="display: flex; align-items: center; justify-content: center; gap: 4px; height: 100%; mask-image: linear-gradient(90deg, transparent, black 20%, black 80%, transparent);">
                ${Array.from({length:24}).map((t,a)=>`<div style="width: 3px; background: #38bdf8; border-radius: 10px; height: 10px; animation: veritas-wave 1s ease-in-out infinite; animation-delay: ${a*.05}s; box-shadow: 0 0 8px rgba(56, 189, 248, 0.4);"></div>`).join("")}
            </div>
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 1px; background: rgba(56, 189, 248, 0.3); box-shadow: 0 0 10px #38bdf8; animation: veritas-scanline 2s linear infinite;"></div>
        </div>
      `,!document.getElementById("veritas-keyframes")){const t=document.createElement("style");t.id="veritas-keyframes",t.textContent=`
            @keyframes veritas-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            @keyframes veritas-pulse-inner { 0%, 100% { transform: translate(-50%, -50%) scale(0.8); opacity: 0.5; } 50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.2; } }
            @keyframes veritas-wave { 0%, 100% { height: 10%; opacity: 0.3; } 50% { height: 70%; opacity: 1; } }
            @keyframes veritas-scanline { 0% { top: 0%; opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { top: 100%; opacity: 0; } }
          `,document.head.appendChild(t)}document.querySelector("#movie_player").appendChild(this.overlay)}showDetailedResult(e){var m,u,f,x,b,w,I,k,E,_;this.overlay&&this.overlay.remove();const t=e.verdict==="LIKELY_REAL",a=e.verdict==="LIKELY_FAKE",i=t?"#22c55e":a?"#ef4444":"#eab308",o=t?"LIKELY REAL":a?"LIKELY FAKE":"UNCERTAIN",n=Math.round((e.confidence||0)*100),s=(e.evidence||[]).map(d=>{const g=d.includes("✅")||d.includes("🔬")||d.includes("⏱️"),A=d.includes("❌")||d.includes("🚨")||d.includes("⚠️");return`<li style="margin-bottom:8px; opacity:0.95; color:${g?"#22c55e":A?"#ef4444":"#e2e8f0"}; font-size:13px; line-height:1.4;">${d}</li>`}).join("");let r="";if((m=e.bio_guard)!=null&&m.pulse_signal&&e.bio_guard.pulse_signal.length>10){const d=e.bio_guard.pulse_signal,g=Math.min(...d),z=Math.max(...d)-g||1;r=`
        <div style="margin-top: 8px; width: 100%; height: 40px; background: rgba(0,0,0,0.2); border-radius: 6px; overflow: hidden; position: relative;">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width: 100%; height: 100%; opacity: 0.8;">
                <polyline points="${d.map(($,M)=>{const L=M/(d.length-1)*100,R=100-($-g)/z*100;return`${L},${R}`}).join(" ")}" fill="none" stroke="${e.bio_guard.pulse_detected?"#22c55e":"#94a3b8"}" stroke-width="2" vector-effect="non-scaling-stroke" />
            </svg>
             <div style="position:absolute; top:2px; left:4px; font-size:8px; color:rgba(255,255,255,0.4);">LIVE SIGNAL</div>
        </div>
        `}this.overlay=document.createElement("div"),this.overlay.className="veritas-glass veritas-fade-in",Object.assign(this.overlay.style,{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",width:"450px",padding:"0",borderRadius:"20px",zIndex:"10000",textAlign:"left",overflow:"hidden",pointerEvents:"auto"});const l=n>=85?"#22c55e":n>=70?"#3b82f6":n>=50?"#eab308":"#ef4444",S=n>=90?"VERY HIGH":n>=80?"HIGH":n>=70?"MODERATE":n>=50?"LOW":"VERY LOW";this.overlay.innerHTML=`
      <div style="padding: 24px; border-bottom: 1px solid rgba(255,255,255,0.1); background: linear-gradient(135deg, ${i}15 0%, transparent 100%);">
         <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
           <h2 style="margin:0; font-size: 28px; font-weight: 900; color: ${i}; letter-spacing: -0.5px; text-shadow: 0 2px 10px ${i}40;">${o}</h2>
         </div>
         <div style="display: flex; align-items: center; gap: 16px;">
           <div style="flex: 1;">
             <div style="font-size: 11px; text-transform: uppercase; letter-spacing: 1px; opacity: 0.6; margin-bottom: 4px;">Confidence Level</div>
             <div style="display: flex; align-items: center; gap: 8px;">
               <div style="flex: 1; height: 8px; background: rgba(255,255,255,0.1); border-radius: 4px; overflow: hidden;">
                 <div style="height: 100%; width: ${n}%; background: linear-gradient(90deg, ${l} 0%, ${l}dd 100%); border-radius: 4px; transition: width 0.5s;"></div>
               </div>
               <div style="font-family: monospace; font-size: 18px; font-weight: 700; color: ${l}; min-width: 50px; text-align: right;">${n}%</div>
             </div>
             <div style="font-size: 10px; color: ${l}; margin-top: 4px; font-weight: 600;">${S} CONFIDENCE</div>
           </div>
         </div>
      </div>
      
      <div style="padding: 24px; background: rgba(0,0,0,0.2);">
        <h4 style="margin:0 0 12px 0; font-size: 12px; text-transform:uppercase; letter-spacing:1px; opacity:0.6;">Forensic Analysis</h4>
        <ul style="margin:0; padding-left: 20px; font-size: 14px; line-height: 1.5; color: #e2e8f0;">
          ${s}
        </ul>
        
        <div style="margin-top: 20px; display:grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
           <div style="background: linear-gradient(135deg, rgba(56, 189, 248, 0.1) 0%, rgba(56, 189, 248, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">BIO-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${(u=e.bio_guard)!=null&&u.pulse_detected?"#22c55e":"#94a3b8"}; margin-bottom:4px;">
               ${(f=e.bio_guard)!=null&&f.pulse_detected?`❤️ ${Math.round(e.bio_guard.bpm)} BPM`:"❌ No Pulse"}
             </div>
             ${(x=e.bio_guard)!=null&&x.snr?`<div style="font-size:11px; opacity:0.7; color:${e.bio_guard.snr>5?"#22c55e":e.bio_guard.snr>2?"#eab308":"#ef4444"};">SNR: ${e.bio_guard.snr.toFixed(1)}</div>`:""}
             ${r}
           </div>
           <div style="background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">PHYSICS-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${(b=e.physics_guard)!=null&&b.is_suspicious?"#ef4444":(w=e.physics_guard)!=null&&w.is_real?"#22c55e":"#94a3b8"}; margin-bottom:4px;">
               ${(I=e.physics_guard)!=null&&I.is_real?"✅ Authentic":(k=e.physics_guard)!=null&&k.is_suspicious?"❌ Suspicious":"⚠️ Uncertain"}
             </div>
             ${(E=e.physics_guard)!=null&&E.confidence?`<div style="font-size:11px; opacity:0.7;">Conf: ${Math.round(e.physics_guard.confidence*100)}%</div>`:""}
           </div>
           ${(_=e.temporal_guard)!=null&&_.available?`
           <div style="background: linear-gradient(135deg, rgba(236, 72, 153, 0.1) 0%, rgba(236, 72, 153, 0.05) 100%); padding: 14px; border-radius: 12px; border: 1px solid rgba(236, 72, 153, 0.2);">
             <div style="font-size:10px; text-transform: uppercase; letter-spacing: 1px; opacity:0.6; margin-bottom:6px; font-weight: 600;">TEMPORAL-GUARD</div>
             <div style="font-weight:700; font-size:16px; color:${e.temporal_guard.temporal_consistency>.7?"#22c55e":e.temporal_guard.temporal_consistency<.4?"#ef4444":"#eab308"}; margin-bottom:4px;">
               ${e.temporal_guard.temporal_consistency>.7?"✅ Consistent":e.temporal_guard.temporal_consistency<.4?"❌ Inconsistent":"⚠️ Moderate"}
             </div>
             <div style="font-size:11px; opacity:0.7;">Score: ${(e.temporal_guard.temporal_consistency*100).toFixed(0)}%</div>
           </div>
           `:""}
        </div>
        
        ${e.summary?`
        <div style="margin-top: 16px; padding: 12px; background: rgba(56, 189, 248, 0.1); border-left: 3px solid #38bdf8; border-radius: 8px;">
          <div style="font-size:12px; font-weight:600; margin-bottom:6px; color:#38bdf8;">SUMMARY</div>
          <div style="font-size:13px; color:#e2e8f0; line-height:1.5;">${e.summary}</div>
        </div>
        `:""}
      </div>
      
      <div style="padding: 16px; background: rgba(0,0,0,0.4); text-align:center;">
        <button id="veritas-close" style="background: transparent; border: none; color: #94a3b8; font-size: 13px; cursor: pointer; text-decoration: underline;">Close Analysis</button>
      </div>
    `,document.querySelector("#movie_player").appendChild(this.overlay),document.getElementById("veritas-close").onclick=d=>{var g;d.stopPropagation(),d.stopImmediatePropagation(),(g=this.overlay)==null||g.remove(),this.overlay=null}}}const C=new v;chrome.runtime.onMessage.addListener((y,e,t)=>{if(y.type==="START_SCAN")return C.handleExternalScan(y,t),!0})})();
